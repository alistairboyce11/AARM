# AARM
Repository of Up-to-date codes for the Absolute arrival-time recovery method (Boyce et. al., BSSA, 2017)
